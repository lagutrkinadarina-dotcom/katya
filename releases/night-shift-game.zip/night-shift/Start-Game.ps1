$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add('http://localhost:8765/')
try {
 $listener.Start()
 Start-Process 'http://localhost:8765/'
 Write-Host 'Game running. Keep this window open. Close it to stop.'
 while ($listener.IsListening) {
  $context = $listener.GetContext()
  try {
   $relative = [Uri]::UnescapeDataString($context.Request.Url.AbsolutePath).TrimStart('/')
   if (!$relative) { $relative = 'index.html' }
   $path = [IO.Path]::GetFullPath((Join-Path $root $relative))
   if (!$path.StartsWith($root + [IO.Path]::DirectorySeparatorChar) -or !(Test-Path -LiteralPath $path -PathType Leaf)) {
    $context.Response.StatusCode = 404
   } else {
    $types = @{'.html'='text/html; charset=utf-8';'.js'='text/javascript';'.css'='text/css';'.png'='image/png';'.glb'='model/gltf-binary';'.json'='application/json'}
    $type = $types[[IO.Path]::GetExtension($path)]
    if (!$type) { $type = 'application/octet-stream' }
    $context.Response.ContentType = $type
    $bytes = [IO.File]::ReadAllBytes($path)
    $context.Response.ContentLength64 = $bytes.Length
    $context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
   }
  } finally { $context.Response.Close() }
 }
} finally { $listener.Close() }
